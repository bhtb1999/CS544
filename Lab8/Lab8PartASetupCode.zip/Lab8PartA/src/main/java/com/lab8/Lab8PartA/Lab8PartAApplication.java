package com.lab8.Lab8PartA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab8PartAApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab8PartAApplication.class, args);
	}

}
