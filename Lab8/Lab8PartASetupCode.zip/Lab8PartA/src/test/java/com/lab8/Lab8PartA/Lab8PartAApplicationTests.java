package com.lab8.Lab8PartA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab8PartAApplicationTests {

	@Test
	void contextLoads() {
	}

}
